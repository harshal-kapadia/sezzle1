import React, { Component } from "react";
import "./App.css";
import ResultComponent from "./components/ResultComponent";
import KeyPadComponent from "./components/KeyPadComponent";

class App extends Component {
  constructor() {
    super();
    // localStorage.clear()
    if (localStorage.getItem("switch_val") === null) {
      var names = {};
      localStorage.setItem("switch_val", JSON.stringify(names));
    }
    this.state = {
      result: "",
    };
  }

  onClick = (button) => {
    if (button === "=") {
      this.calculate();
    } else if (button === "C") {
      this.reset();
    } else if (button === "CE") {
      this.backspace();
    } else {
      this.setState({
        result: this.state.result + button,
      });
    }
  };

  calculate = () => {
    try {
      var obj = JSON.parse(localStorage.getItem("switch_val"));
      this.setState({
        // eslint-disable-next-line
        result: (eval(this.state.result) || "") + "",
      });
      obj[this.state.result] = String(eval(this.state.result));
      localStorage.setItem("switch_val", JSON.stringify(obj));
      this.forceUpdate();
      this.setState({
        result: "",
      });
    } catch (e) {
      this.setState({
        result: "error",
      });
    }
  };

  reset = () => {
    this.setState({
      result: "",
    });
  };

  backspace = () => {
    this.setState({
      result: this.state.result.slice(0, -1),
    });
  };

  render() {
    let obj = JSON.parse(localStorage.getItem("switch_val"));
    let count = 0;
    return (
      <div style={{}}>
        <div className="calculator-body">
          <h1 style={{ alignContent: "center", marginLeft: "50px" }}>
            Sezzle Calculator
          </h1>
          <br></br>
          <ResultComponent result={this.state.result} />
          <KeyPadComponent onClick={this.onClick} />
        </div>
        <br></br>
        <br></br>
        <table
          style={{
            background: "#d3d3d3",
            border: "5",
            borderCollapse: "collapse",
          }}
          cellPadding="5"
        >
          <tr>
            <th className="tableHead">#</th>
            <th className="tableHead">Input</th>
            <th className="tableHead">Result</th>
          </tr>

          {Object.keys(obj)
            .reverse()
            .map((ans, i) => {
              count += 1;
              if (count <= 10) {
                return (
                  <>
                    <tr>
                      <td className="items">{count}</td>
                      <td className="items">{ans}</td>
                      <td className="items">{obj[ans]}</td>
                    </tr>
                  </>
                );
              }
            })}
        </table>
      </div>
    );
  }
}

export default App;
