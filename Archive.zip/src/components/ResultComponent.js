import React, { Component } from "react";

class ResultComponent extends Component {
  render() {
    let { result } = this.props;
    return (
      <>
        <div className="result">
          <p
            style={{
              marginLeft: "5%",
              background: "#d3d3d3",
              width: "280px",
              padding: "0px",
            }}
          >
            {result}
          </p>
        </div>
      </>
    );
  }
}

export default ResultComponent;
